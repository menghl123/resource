export declare class Particle {
    x: number;
    y: number;
    r: number;
    vx: number;
    vy: number;
    color: string;
    constructor(...args: any[]);
}
