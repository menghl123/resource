"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Particle = (function () {
    function Particle() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        this.x = args[0], this.y = args[1], this.r = args[2], this.vx = args[3], this.vy = args[4], this.color = args[5];
    }
    return Particle;
}());
exports.Particle = Particle;
//# sourceMappingURL=partical.js.map