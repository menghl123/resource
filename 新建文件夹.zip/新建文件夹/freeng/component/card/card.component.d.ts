import { OnInit } from '@angular/core';
export declare class CardHeaderComponent {
}
export declare class CardFooterComponent {
}
export declare class CardMediaComponent {
}
export declare class CardContentComponent {
}
export declare class CardHeaderTextComponent {
}
export declare class CardComponent implements OnInit {
    direction: string;
    hover: boolean;
    cardClass: {};
    constructor();
    ngOnInit(): void;
}
export declare class CardModule {
}
