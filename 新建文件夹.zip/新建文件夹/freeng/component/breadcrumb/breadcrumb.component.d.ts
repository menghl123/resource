export declare class BreadcrumbComponent {
    menus: any;
    separator: string;
    icon: string;
    constructor();
}
export declare class BreadcrumbModule {
}
