import { OnInit } from '@angular/core';
export declare class PanelComponent implements OnInit {
    header: string;
    theme: string;
    panelClass: any;
    constructor();
    ngOnInit(): void;
}
export declare class PanelModule {
}
