import { SassngPage } from './app.po';

describe('sassng App', () => {
  let page: SassngPage;

  beforeEach(() => {
    page = new SassngPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
