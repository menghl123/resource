import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AccordionModule} from 'freeng/freeng';
import {ButtonModule} from 'freeng/freeng';
import { AppComponent } from './app.component';
import {IconModule} from 'freeng/freeng';
import {SidenavModule} from 'freeng/freeng';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AccordionModule,
    ButtonModule,
    IconModule,
    SidenavModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
