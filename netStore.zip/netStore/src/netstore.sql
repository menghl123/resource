create database netstore;
use netstore;
create table Category(
	id varchar(100) primary key,
	name varchar(100) unique,
	description varchar(255)

)

create table Book(
	id varchar(100) primary key,
	name varchar(100) unique,
	author varchar(100) ,
	price varchar(100),
	path varchar(100),
	photoFileName varchar(100),
	description varchar(255),
	categoryId varchar(100),
	constraint category_id_fk foreign key(categoryId) references category(id) 
)character set utf8;