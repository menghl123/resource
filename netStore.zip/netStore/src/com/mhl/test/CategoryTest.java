package com.mhl.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.mhl.dao.CategoryDao;
import com.mhl.dao.impl.CategoryDaoImpl;
import com.mhl.domain.Category;
import com.mhl.service.BusinessService;
import com.mhl.service.impl.BusinessServiceImpl;

public class CategoryTest {

	@Test
	public void test() {
		BusinessService bs = new BusinessServiceImpl();
		Category c = new Category();
		c.setDescription("��1Ҳ����һ����Ů�������ҵ��Ϲ��϶���˧��");
		
		c.setName("����1��");
		bs.addCategory(c);
	}

	@Test
	public void test1() {
		BusinessService bs = new BusinessServiceImpl();
		bs.findAllCategory();
		System.out.println(bs.findAllCategory());
	}

}
