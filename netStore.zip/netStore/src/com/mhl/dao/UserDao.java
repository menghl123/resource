package com.mhl.dao;

import com.mhl.permisson.domain.User;

public interface UserDao {

	User find(String username, String password);

}
