package com.mhl.dao;

import java.util.List;

import com.mhl.domain.Category;

public interface CategoryDao {

	

	List<Category> findAll();

	Category findById(String id);

	void save(Category c);

	void deleteById(String id);

}
