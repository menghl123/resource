package com.mhl.dao;

import java.util.List;

import com.mhl.permisson.domain.Role;
import com.mhl.permisson.domain.User;

public interface RoleDao {

	List<Role> findRoles(User user);

}
