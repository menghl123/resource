package com.mhl.dao;

import java.util.List;

import com.mhl.permisson.domain.Function;
import com.mhl.permisson.domain.Role;

public interface FunctionDao {

	List<Function> findFunctions(Role role);

}
