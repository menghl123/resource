package com.mhl.dao.impl;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.mhl.dao.FunctionDao;
import com.mhl.exception.DaoException;
import com.mhl.permisson.domain.Function;
import com.mhl.permisson.domain.Role;
import com.mhl.utils.DBCPUtil;



public class FunctionDaoImpl implements FunctionDao {
	private QueryRunner qr = new QueryRunner(DBCPUtil.getDataSource());
	public List<Function> findFunctions(Role role) {
		try {
			return qr.query("select f.* from functions f,roles_functions rf where f.id=rf.f_id and rf.r_id=?", 
					new BeanListHandler<Function>(Function.class),role.getId());
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

}
