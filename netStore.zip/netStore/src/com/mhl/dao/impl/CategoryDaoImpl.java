package com.mhl.dao.impl;

import java.sql.SQLException;
import java.util.List;

import javax.management.RuntimeErrorException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.mhl.dao.CategoryDao;
import com.mhl.domain.Category;
import com.mhl.exception.DaoException;
import com.mhl.utils.DBCPUtil;

public class CategoryDaoImpl implements CategoryDao {
	private QueryRunner qr = new QueryRunner(DBCPUtil.getDataSource());
	public void save(Category c) {
		 try {
			qr.update("insert into category (id,name,description) values(?,?,?)",c.getId(),c.getName(),c.getDescription());
		} catch (SQLException e) {
			throw new DaoException(e);
		}
	}

	public List<Category> findAll() {
		try {
			return qr.query("select * from category ",new BeanListHandler<Category>(Category.class));
		} catch (SQLException e) {
			throw new DaoException(e);
		}
	}

	public Category findById(String id) {
		try {
			return qr.query("select * from category where id = ?",new BeanHandler<Category>(Category.class),id);
		} catch (SQLException e) {
			throw new DaoException(e);
		}
	}

	public void deleteById(String id) {
		try {
			qr.update("delete from Category where id =? ",id);
		} catch (SQLException e) {
			throw new DaoException(e);
		}
	}

	

}
