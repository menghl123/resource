package com.mhl.dao.impl;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.mhl.dao.UserDao;
import com.mhl.exception.DaoException;
import com.mhl.permisson.domain.User;
import com.mhl.utils.DBCPUtil;



public class UserDaoImpl implements UserDao {
	private QueryRunner qr = new QueryRunner(DBCPUtil.getDataSource());
	public User find(String username, String password) {
		try {
			return qr.query("select * from users where username=? and password=?", new BeanHandler<User>(User.class),username,password);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}
	
}
