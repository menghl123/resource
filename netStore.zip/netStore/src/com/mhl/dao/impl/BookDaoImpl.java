package com.mhl.dao.impl;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.mhl.dao.BookDao;
import com.mhl.domain.Book;
import com.mhl.exception.DaoException;
import com.mhl.utils.DBCPUtil;

public class BookDaoImpl implements BookDao {
	private QueryRunner qr = new QueryRunner(DBCPUtil.getDataSource());
	public void save(Book book) {
		try{
			qr.update("insert into book (id,name,author,price,path,photoFileName,description,categoryId) values (?,?,?,?,?,?,?,?)", 
					book.getId(),
					book.getName(),
					book.getAuthor(),
					book.getPrice(),
					book.getPath(),
					book.getPhotoFileName(),
					book.getDescription(),
					book.getCategoryId());
		}catch(Exception e){
			throw new DaoException(e);
		}
	}

	public Book findById(String id) {
		try{
			return qr.query("select * from book where id=?", new BeanHandler<Book>(Book.class),id);
		}catch(Exception e){
			throw new DaoException(e);
		}
	}

	public int findAllBooksNumber() {
		try{
			Object obj = qr.query("select count(*) from book", new ScalarHandler(1));
			Long num = (Long)obj;
			return num.intValue();
		}catch(Exception e){
			throw new DaoException(e);
		}
	}

	public List<Book> findPageBooks(int startIndex, int offset) {
		try{
			return qr.query("select * from book limit ?,?", new BeanListHandler<Book>(Book.class),startIndex,offset);
		}catch(Exception e){
			throw new DaoException(e);
		}
	}

	public void delById(String id) {
		try{
			 qr.update("delete from book where id = ?",id);
		}catch(Exception e){
			throw new DaoException(e);
		}
	}

	public int findCategoryBooksNumber(String categoryId) {
		try{
			Object obj = qr.query("select count(*) from book where categoryId=?", new ScalarHandler(1),categoryId);
			Long num = (Long)obj;
			return num.intValue();
		}catch(Exception e){
			throw new DaoException(e);
		}
	}

	public List findPageBooks(int startIndex, int pageSize, String categoryId) {
		try{
			return qr.query("select * from book where categoryId=? limit ?,?", new BeanListHandler<Book>(Book.class),categoryId,startIndex,pageSize);
		}catch(Exception e){
			throw new DaoException(e);
		}
	}


}
