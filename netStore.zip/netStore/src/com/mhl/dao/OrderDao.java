package com.mhl.dao;

import java.util.List;

import com.mhl.domain.Order;

public interface OrderDao {

	void save(Order order);

	void update(Order order);

	Order findById(String orderId);

	List<Order> findOrdersByCustomerId(String id);

	Order findByOrderNum(String orderNum);

}
