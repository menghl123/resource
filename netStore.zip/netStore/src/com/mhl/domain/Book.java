package com.mhl.domain;

import java.io.Serializable;

public class Book implements Serializable {

	
		@Override
	public String toString() {
		return "Book [name=" + name + ", author=" + author + ", price=" + price + ", description=" + description + "]";
	}
		private String id;
		private String name;
		private String author;
		private String price;
		private String path;
		private String photoFileName;
		private String description;
		private String categoryId;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		public String getPrice() {
			return price;
		}
		public void setPrice(String price) {
			this.price = price;
		}
		public String getPath() {
			return path;
		}
		public void setPath(String path) {
			this.path = path;
		}
		public String getPhotoFileName() {
			return photoFileName;
		}
		public void setPhotoFileName(String photoFileName) {
			this.photoFileName = photoFileName;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getCategoryId() {
			return categoryId;
		}
		public void setCategoryId(String categoryId) {
			this.categoryId = categoryId;
		}
	

}
