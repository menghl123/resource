package com.mhl.domain;

import java.io.Serializable;

//ʵ���࣬���������ģ�ͣ���id,name,description
public class Category  implements Serializable{
	String id;//ʹ��uuid������id
	String name;
	String description;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
