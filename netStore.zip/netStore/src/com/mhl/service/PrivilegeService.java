package com.mhl.service;

import java.util.List;

import com.mhl.permisson.domain.Function;
import com.mhl.permisson.domain.Role;
import com.mhl.permisson.domain.User;

public interface PrivilegeService {
	/**
	 * �û���¼
	 * @param username
	 * @param password
	 */
	User login(String username,String password);
	/**
	 * �����û���ѯӵ�еĽ�ɫ
	 * @param user
	 * @return
	 */
	List<Role> findRoles(User user);
	/**
	 * ���ݽ�ɫ��ѯ����
	 * @param role
	 * @return
	 */
	List<Function> findFunctions(Role role);
	
}
