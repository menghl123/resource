package com.mhl.service.impl;

import java.util.List;

import com.mhl.dao.FunctionDao;
import com.mhl.dao.RoleDao;
import com.mhl.dao.UserDao;
import com.mhl.dao.impl.FunctionDaoImpl;
import com.mhl.dao.impl.RoleDaoImpl;
import com.mhl.dao.impl.UserDaoImpl;
import com.mhl.permisson.domain.Function;
import com.mhl.permisson.domain.Role;
import com.mhl.permisson.domain.User;
import com.mhl.service.PrivilegeService;

public class PrivilegeServiceImpl implements PrivilegeService {
	private UserDao userDao = new UserDaoImpl();
	private RoleDao roleDao = new RoleDaoImpl();
	private FunctionDao functionDao = new FunctionDaoImpl();
	public User login(String username, String password) {
		return userDao.find(username,password);
	}

	public List<Role> findRoles(User user) {
		return roleDao.findRoles(user);
	}

	public List<Function> findFunctions(Role role) {
		return functionDao.findFunctions(role);
	}

}
