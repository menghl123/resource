package com.mhl.service.impl;

import java.util.List;
import java.util.UUID;

import com.mhl.common.Page;
import com.mhl.dao.BookDao;
import com.mhl.dao.CategoryDao;
import com.mhl.dao.CustomerDao;
import com.mhl.dao.OrderDao;
import com.mhl.dao.impl.BookDaoImpl;
import com.mhl.dao.impl.CategoryDaoImpl;
import com.mhl.dao.impl.CustomerDaoImpl;
import com.mhl.dao.impl.OrderDaoImpl;
import com.mhl.domain.Book;
import com.mhl.domain.Category;
import com.mhl.domain.Customer;
import com.mhl.domain.Order;
import com.mhl.service.BusinessService;

public class BusinessServiceImpl implements BusinessService {
	private CategoryDao categoryDao = new CategoryDaoImpl();
	private BookDao bookDao = new BookDaoImpl();
	private CustomerDao customerDao = new CustomerDaoImpl();
	private OrderDao orderDao = new OrderDaoImpl();
	public void addCategory(Category c) {
		c.setId(UUID.randomUUID().toString());
		categoryDao.save(c);
	}

	public List<Category> findAllCategory() {
		return categoryDao.findAll();
	}

	public Category findCategoryById(String id) {
		return categoryDao.findById(id);
	}

	public void addBook(Book book) {
		book.setId(UUID.randomUUID().toString());
		bookDao.save(book);
	}

	public Book findBookById(String id) {
		
		return bookDao.findById(id);
	}

	public Page findAllBookPageRecords(String pagenum) {
		int currentPageNum =1;
		if(pagenum!=null){
			currentPageNum = Integer.parseInt(pagenum);
		}
		int totalRecords = bookDao.findAllBooksNumber();
		Page page = new Page(currentPageNum, totalRecords);
		
		page.setRecords(bookDao.findPageBooks(page.getStartIndex(), page.getPageSize()));
		
		return page;
	}

	public void deleteCategoryById(String id) {
		categoryDao.deleteById(id);
		
	}

	public void delBookById(String id) {
		bookDao.delById(id);
	}

	public Page findAllBookPageRecords(String pagenum, String categoryId) {
		int currentPageNum = 1;
		if(pagenum!=null){
			currentPageNum = Integer.parseInt(pagenum);
		}
		int totalRecords = bookDao.findCategoryBooksNumber(categoryId);
		Page page = new Page(currentPageNum, totalRecords);
		
		page.setRecords(bookDao.findPageBooks(page.getStartIndex(), page.getPageSize(),categoryId));
		
		return page;
	}

	public void regitsCustomer(Customer c) {
		c.setId(UUID.randomUUID().toString());
		customerDao.save(c);
	}

	public void activeCustomer(String code) {
		Customer c = customerDao.findByCode(code);
		c.setActived(true);
		customerDao.update(c);
	}

	public Customer customerLogin(String username, String password) {
		Customer c = customerDao.findCustomer(username,password);
		if(c==null)
			return null;
		if(!c.isActived())
			return null;
		return c;
	}
	public void genOrder(Order order) {
		if(order.getCustomer()==null)
			throw new IllegalArgumentException("�����Ŀͻ�����Ϊ��");
		order.setId(UUID.randomUUID().toString());
		orderDao.save(order);
	}

	public void updateOrder(Order order) {
		orderDao.update(order);
	}

	public Order findOrderById(String orderId) {
		return orderDao.findById(orderId);
	}

	public Order findOrderByOrderNum(String orderNum) {
		return orderDao.findByOrderNum(orderNum);
	}

	public List<Order> findOrdersByCustomer(Customer c) {
		return orderDao.findOrdersByCustomerId(c.getId());
	}
}
