package com.mhl.web.controller;

import java.io.IOException;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mhl.common.Page;
import com.mhl.domain.Book;
import com.mhl.domain.Category;
import com.mhl.service.BusinessService;
import com.mhl.service.impl.BusinessServiceImpl;
import com.mhl.utils.FillBeanUtil;


/**
 * Servlet implementation class ControlServlet
 */
@WebServlet("/ControlServlet")
public class ControlServlet extends HttpServlet {
	private BusinessService s = new BusinessServiceImpl();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String op = request.getParameter("op");
		if("addCategory".equals(op)){
			addCategory(request,response);
		}else if("findAllCategory".equals(op)){
			findAllCategory(request,response);
		}else if("showAddBookUI".equals(op)){
			showAddBookUI(request,response);
		}else if("addBook".equals(op)){
			try {
				addBook(request,response);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}else if("showAllBooks".equals(op)){
			showAllBooks(request,response);
		}else if("deleteCategory".equals(op)){
			String id = request.getParameter("CategoryId");
			deleteCategoryByid(request,response,id);
		}else if("delBook".equals(op)){
			String id = request.getParameter("id");
			delBook(request,response,id);
		}
	}
	//����idɾ��һ����
	private void delBook(HttpServletRequest request, HttpServletResponse response, String id) throws ServletException,IOException{
		// TODO Auto-generated method stub
		s.delBookById(id);
		request.getRequestDispatcher("/ControlServlet?op=showAllBooks").forward(request, response);
	}
	//���ݲ���idɾ��category
	private void deleteCategoryByid(HttpServletRequest request, HttpServletResponse response, String id) throws ServletException,IOException {
		s.deleteCategoryById(id);
		request.getRequestDispatcher("/ControlServlet?op=findAllCategory").forward(request, response);
		
	}
	//չʾ���е��鼮
	private void showAllBooks(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		String pagnum = request.getParameter("num");
		
		Page page = s.findAllBookPageRecords(pagnum);page.setUrl("/servlet/ControlServlet?op=showAllBooks");
		page.setUrl("/ControlServlet?op=showAllBooks");
		request.setAttribute("page", page);

		request.getRequestDispatcher("/manager/listBooks.jsp").forward(request, response);
	}
	//����ͼ��
	private void addBook(HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if(!isMultipart){
			request.setAttribute("msg","���ǣ���ı�����������");
			request.getRequestDispatcher("/manage/message.jsp").forward(request, response);
			return;
		}
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(factory);
		List<FileItem> items = sfu.parseRequest(request);
		
		Book book = new Book();
		for(FileItem item:items){
			//��װ�������ݵ�Book��
			if(item.isFormField()){
				String fieldName = item.getFieldName();
				String fieldValue = item.getString(request.getCharacterEncoding());
				BeanUtils.setProperty(book,fieldName, fieldValue);
			}else{
				//�ļ��ϴ�
				String fileName = item.getName();
				if(fileName!=null&&!fileName.trim().equals("")){
					//���ļ�����Ψһ���ļ���
					fileName = UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(fileName);
					//����洢·��
					String storeDirectory = getServletContext().getRealPath("/images");
					String path = makeDirs(storeDirectory, fileName);//   /dir1/dir2
					
					book.setPath(path);
					book.setPhotoFileName(fileName);
					
					//�ϴ�
					item.write(new File(storeDirectory+path+"/"+fileName));
				}
			}
		}
		//�����鼮��Ϣ�����ݿ���
		s.addBook(book);
		request.setAttribute("msg","�鼮����ɹ���");
		request.getRequestDispatcher("/manager/message.jsp").forward(request, response);
	}
	//����·��
	public String makeDirs(String storeDirecotry,String filename){
		int hashCode = filename.hashCode();
		int dir1 = hashCode&0xf;
		int dir2 = (hashCode&0xf0)>>4;
		
		String newPath = "/"+dir1+"/"+dir2;
		File file = new File(storeDirecotry, newPath);
		if(!file.exists()){
			file.mkdirs();
		}
		return newPath;
		
	}
	//��ս������ͼ���ҳ��
	private void showAddBookUI(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		List<Category> cs = s.findAllCategory();
		request.setAttribute("cs", cs);
		request.getRequestDispatcher("/manager/addBook.jsp").forward(request, response);
	}
	//��ѯ���е�ͼ�����
	private void findAllCategory(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		List<Category> cs = s.findAllCategory();
		request.setAttribute("cs", cs);
		request.getRequestDispatcher("/manager/listCategory.jsp").forward(request, response);
	}
	//����һ��ͼ�����
	private void addCategory(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		Category category = FillBeanUtil.fillBean(request, Category.class);
		s.addCategory(category);
		request.setAttribute("msg","����ɹ���");
		request.getRequestDispatcher("/manager/message.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
